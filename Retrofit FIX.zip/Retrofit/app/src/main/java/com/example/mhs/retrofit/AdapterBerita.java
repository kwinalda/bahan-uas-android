package com.example.mhs.retrofit;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mhs.retrofit.network.InitRetrofit;
import com.example.mhs.retrofit.response.BeritaItem;
import com.squareup.picasso.Picasso;

import java.util.List;

//ALT ENTER PADA AdapterBerita, MyViewHolder, AdapterBerita
public class AdapterBerita extends RecyclerView.Adapter<AdapterBerita.MyViewHolder> {
    Context context;
    List<BeritaItem> berita;

    //TEKAN ALT+INSERT AGAR MEMBUAT CONSTRUCTOR DENGAN CEPAT
    public AdapterBerita(Context context, List<BeritaItem> berita) {
        this.context = context;
        this.berita = berita;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_berita, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {

        holder.textViewJudul.setText(berita.get(position).getJudulBerita());
        holder.textViewTanggal.setText(berita.get(position).getTanggalPosting());
        holder.textViewPenulis.setText(berita.get(position).getPenulis());
        final String urlGambarBerita = InitRetrofit.API_URL + "images/" + berita.get(position).getFoto();
        Picasso.with(context).load(urlGambarBerita).into(holder.imageView);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Main2Activity.class);
                intent.putExtra("id", berita.get(position).getId());
                intent.putExtra("foto", urlGambarBerita);
                intent.putExtra("judul", berita.get(position).getJudulBerita());
                intent.putExtra("tgl", berita.get(position).getTanggalPosting());
                intent.putExtra("isi", berita.get(position).getIsiBerita());
                intent.putExtra("penulis", berita.get(position).getPenulis());

                context.startActivity(intent);


            }
        });
    }

    @Override
    public int getItemCount() {
        return berita.size();
    }

    //ALT+ENTER KE RecyclerView
    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textViewJudul, textViewTanggal, textViewPenulis;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageBerita);
            textViewJudul = itemView.findViewById(R.id.judulBerita);
            textViewTanggal = itemView.findViewById(R.id.tanggalBerita);
            textViewPenulis = itemView.findViewById(R.id.penulisBerita);
        }
    }
}
