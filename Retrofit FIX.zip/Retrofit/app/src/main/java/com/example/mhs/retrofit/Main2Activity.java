package com.example.mhs.retrofit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mhs.retrofit.network.ApiService;
import com.example.mhs.retrofit.network.InitRetrofit;
import com.example.mhs.retrofit.response.ResponseInput;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//ALT+ENTER DI ONCLICKLISTER
public class Main2Activity extends AppCompatActivity implements View.OnClickListener {

    EditText editTextId, editTextFoto, editTextJudul, editTextTanggal, editTextIsi, editTextPenulis;
    Button buttonSave, buttonUpdate, buttonView, buttonDelete;
    String ifoto, ijudul, itgl, iisi, ipenulis;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        editTextId = findViewById(R.id.idBerita);
        editTextFoto = findViewById(R.id.fotoBerita);
        editTextJudul = findViewById(R.id.judulBerita);
        editTextTanggal = findViewById(R.id.tanggalBerita);
        editTextIsi = findViewById(R.id.isiBerita);
        editTextPenulis = findViewById(R.id.penulisBerita);

        buttonSave = findViewById(R.id.btnSave);
        buttonUpdate = findViewById(R.id.btnUpdate);
        buttonView = findViewById(R.id.btnView);
        buttonDelete = findViewById((R.id.btnDelete));

        buttonSave.setOnClickListener(this);
        buttonUpdate.setOnClickListener(this);
        buttonView.setOnClickListener(this);
        buttonDelete.setOnClickListener(this);

        Intent intentReceive = getIntent();

        String uid = intentReceive.getStringExtra("id");
        String ufoto = intentReceive.getStringExtra("foto");
        String ujudul = intentReceive.getStringExtra("judul");
        String utgl = intentReceive.getStringExtra("tgl");
        String uisi = intentReceive.getStringExtra("isi");
        String upenulis = intentReceive.getStringExtra("penulis");

        editTextId.setText(uid);
        editTextFoto.setText(ufoto);
        editTextJudul.setText(ujudul);
        editTextTanggal.setText(utgl);
        editTextIsi.setText(uisi);
        editTextPenulis.setText(upenulis);

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ApiService api = InitRetrofit.getInstance();
                Call<ResponseInput> call = api.delete(editTextId.getText().toString());
                call.enqueue(new Callback<ResponseInput>() {
                    @Override
                    public void onResponse(Call<ResponseInput> call, Response<ResponseInput> response) {
                        String value = response.body().getValue();
                        String message = response.body().getMessage();

                        if (value.equals("1")) {
                            Toast.makeText(Main2Activity.this, "SUDAH DI DELETE SAYANG", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Main2Activity. this, MainActivity.class);
                            finish();
                            startActivity(intent);
                        } else {
                            Toast.makeText(Main2Activity.this, "CEK LAGI DONG SAYANG", Toast.LENGTH_SHORT).show();
                        }

                    }

                    @Override
                    public void onFailure(Call<ResponseInput> call, Throwable t) {
                        Toast.makeText(Main2Activity.this, "Jaringan Error! "+t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ApiService api = InitRetrofit.getInstance();
                Call<ResponseInput> call = api.update(editTextId.getText().toString(), editTextFoto.getText().toString(), editTextJudul.getText().toString(), editTextTanggal.getText().toString(), editTextIsi.getText().toString(), editTextPenulis.getText().toString());
                call.enqueue(new Callback<ResponseInput>() {
                    @Override
                    public void onResponse(Call<ResponseInput> call, Response<ResponseInput> response) {
                        String value = response.body().getValue();
                        String message = response.body().getMessage();

                        if (value.equals("1")){
                            Toast.makeText(Main2Activity.this, "SUDAH DI UPDATE SAYANG", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Main2Activity. this, MainActivity.class);
                            finish();
                            startActivity(intent);
                        } else {
                            Toast.makeText(Main2Activity.this, "CEK LAGI DONG SAYANG", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseInput> call, Throwable t) {

                    }
                });
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v == buttonSave) {
            insertData();
        } else if (v == buttonUpdate) {

        } else if (v == buttonView) {
            Intent intent = new Intent(Main2Activity.this, MainActivity.class);
            startActivity(intent);
        }
    }

    private void insertData() {
        //mengambil data dari edittext
        ifoto = editTextFoto.getText().toString();
        ijudul= editTextJudul.getText().toString();
        itgl = editTextTanggal.getText().toString();
        iisi = editTextIsi.getText().toString();
        ipenulis = editTextPenulis.getText().toString();

        ApiService api = InitRetrofit.getInstance();

        //memanggil fungsi insert dari class ApiService
        Call<ResponseInput> call = api.input(ifoto, ijudul, itgl, iisi, ipenulis);
        call.enqueue(new Callback<ResponseInput>() {
            @Override
            public void onResponse(Call<ResponseInput> call, Response<ResponseInput> response) {
                String value = response.body().getValue();
                String message = response.body().getMessage();

                if (value.equals("1")) {
                    Toast.makeText(Main2Activity.this, message, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Main2Activity.this, message, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseInput> call, Throwable t) {
//                Log.d("test", t.getMessage());
                Toast.makeText(Main2Activity.this, "Jaringan Error! "+t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }



}
