package com.example.mhs.retrofit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.mhs.retrofit.network.InitRetrofit;
import com.example.mhs.retrofit.response.BeritaItem;
import com.example.mhs.retrofit.response.ResponseBerita;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.rvBerita);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //ALT+ENTER di tampilBerita
        tampilBerita();
    }

    private void tampilBerita() {
        Call<ResponseBerita> beritaCall = InitRetrofit.getInstance().request_show_all_berita();
        beritaCall.enqueue(new Callback<ResponseBerita>() {
            @Override
            public void onResponse(Call<ResponseBerita> call, Response<ResponseBerita> response) {
                //CEK RESPONSE JSON SUKSES
                if (response.isSuccessful()){
                    List<BeritaItem> dataBerita = response.body().getBerita();
                    AdapterBerita adapterBerita = new AdapterBerita(MainActivity.this, dataBerita);

                    //SET ADAPTER
                    recyclerView.setAdapter(adapterBerita);
                }
            }

            @Override
            public void onFailure(Call<ResponseBerita> call, Throwable t) {

            }
        });
    }
}
