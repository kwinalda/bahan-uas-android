package com.example.mhs.retrofit.network;

import retrofit2.Call;
import com.example.mhs.retrofit.response.ResponseBerita;
import com.example.mhs.retrofit.response.ResponseInput;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiService {
    @GET("tampil_berita.php")
    Call<ResponseBerita> request_show_all_berita();

    @FormUrlEncoded
    @POST("insert.php")
    //MEMANGGIL INPUT RESPONSE
    Call<ResponseInput> input
    (        @Field("foto") String foto,
             @Field("judul_berita") String judul,
             @Field("tanggal_posting") String tanggal_posting,
             @Field("isi_berita") String isi_berita,
             @Field("penulis") String penulis
    );

    @FormUrlEncoded
    @POST("update.php")
    //MEMANGGIL INPUT RESPONSE
    Call<ResponseInput> update
    (         @Field("id") String id,
              @Field("foto") String foto,
              @Field("judul_berita") String judul,
              @Field("tanggal_posting") String tanggal_posting,
              @Field("isi_berita") String isi_berita,
              @Field("penulis") String penulis
    );

    @FormUrlEncoded
    @POST("delete.php")
        //MEMANGGIL INPUT RESPONSE
    Call<ResponseInput> delete
    (         @Field("id") String id
    );
}
