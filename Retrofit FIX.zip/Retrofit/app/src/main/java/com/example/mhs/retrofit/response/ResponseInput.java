package com.example.mhs.retrofit.response;

import com.google.gson.annotations.SerializedName;

public class ResponseInput {
    @SerializedName("value")
    String value;

    @SerializedName("message")
    String message;

    public String getValue() {
        return value;
    }

    public String getMessage() {
        return message;
    }
}
